=== Adam Projection ===
Target Platform: TradeStation (tested on TS2000i and TS 8)
Contributor: souly (email: souly(at)soulytion.de)
Link: http://www.soulytion.de

Please feel free to contact me when you have requests or comments.




== Description ==

Draws the Adam Projection (Reflection) in your chart


== Features ==

- Projection can be drawn as line or full bars 
- Works in every time frame (intraday, EoD) 
- Realitime updates in live ticking charts 
- Set any date/time as start of your projection (allows backtesting) 



== Instructions ==

- Don't forget to add Space to the Right of your chart

- you can set the start of the reflection
	1. Enable the Expert Commentary tool
	2. Click on a bar on the chart and it will be the Mirror-Bar

- set drawLine to '1' and you will get a Projection Line based on close prices

- set drawBars to '1' and you will get Projection Bars based on H/L of the bars



== Installation ==

Just import the ELS in your TradeStation


== Licence ==

This indicator is free