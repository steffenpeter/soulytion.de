=== [SOULY] eclipse ===
Target Platform: TradeStation (tested on TS2000i and TS 8)
Contributor: souly (email: souly(at)soulytion.de)
Link: http://www.soulytion.de


== Description ==

Indicates Dates of total and partial sun and moon eclipses from 1901-2050

white bars (default, can be changed) indicate moon eclipses
yellow bars (default, can be changed) indicate sun eclipses

high bars (2), show total eclipse
lower bars (1), show partial eclipse - can be disabled



== Installation ==

Just import the ELS in your TradeStation


== Licence ==

This indicator is free